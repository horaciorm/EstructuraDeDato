#pragma once
#include "Cuenta.h"
#include <iostream>
#include <string>
using namespace std;
class CuentaAhorro:public  Cuenta
{
private:
double cuotaMantenimiento;
public:
	CuentaAhorro();
	void Set_CuotaManten(double cantidad);
	double Get_CuotaManten();
	void reintegro(double cantidad);
};

