#pragma once
#include "Dato.h"
class Nodo
{
public:
	Dato dato; 
    Nodo *puntero; 
public:
	Nodo(void);
	~Nodo(void);
};

