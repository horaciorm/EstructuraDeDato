#include "StdAfx.h"
#include "Dato.h"


Dato::Dato(void)
{
	Codigo = 0; 
    Nombre = "Unknow"; 
    Carrera = "Unknow";
}


Dato::~Dato(void)
{
}
