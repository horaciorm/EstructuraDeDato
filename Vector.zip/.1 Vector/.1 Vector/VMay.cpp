#include "StdAfx.h"
#include "VMay.h"
#include <iostream>
#define MAX 10
using namespace std;

VMay::VMay(void)
{
	V[MAX]=0;
	tamano=0;

}
double VMay::Get_Vector(int posicion)
{
	return V[posicion];
}
void VMay::Set_Vector(double elemento,int posicion)
{
	V[posicion]=elemento;
}
int VMay::Get_Tamano()
{
	return tamano;
}
void VMay::Set_Tamano(int tam)
{
	tamano=tam;
}
bool VMay::Lleno_Vector()
{
	if(tamano==(MAX-1))
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool VMay::Vacio_Vector()
{
	if(tamano==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool VMay::Ingresar_Vector(double elemento,int posicion)
{
	if((posicion<0)&&(posicion>tamano))
	{
		return false;

	}
	else
	{
		if(Lleno_Vector()==true)
		{
			return false;
		}
		else
		{
			int i=Get_Tamano();
			while(i>posicion)
			{
				V[i]=V[i-1];
				i--;
			}
			V[posicion]=elemento;
			return true;
		}
	}
}
double VMay::Mayor_Vector()
{
	int may=V[0];
	for(int i=0;i<Get_Tamano();i++)
	{
		if(V[i]>may)
		{
			may=V[i];
		}
	}
	return may;
}

